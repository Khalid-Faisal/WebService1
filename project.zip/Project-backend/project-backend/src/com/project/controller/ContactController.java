package com.project.controller;

import com.project.dao.ContactDAO;
import com.project.dao.impl.ContactDAOImpl;
import com.project.model.Contact;

public class ContactController {

	public static void main(String[] args) {
		ContactDAO  dao = new ContactDAOImpl();
		
		Contact contact = new Contact(0, "Khalid", "khalid.datamax@gmail.com", 8983746099L, "Own");
		
		dao.saveContact(contact);
		
		System.out.println("contact saved successfully");

	}

}
