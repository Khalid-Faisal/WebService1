package com.project.controller;

import com.project.dao.UserDAO;
import com.project.dao.impl.UserDAOImpl;
import com.project.model.User;

public class UserController {

	public static void main(String[] args) {
		UserDAO dao = new UserDAOImpl();
		
		User user = new User(0, "Khalid","khalid.datamax@gmail.com","Khalid17", 8983746099L, "Mehrun Jalgaon", "image7.png");
		
		dao.saveUser(user);
		System.out.println("Inserted Successfully");

	}

}
