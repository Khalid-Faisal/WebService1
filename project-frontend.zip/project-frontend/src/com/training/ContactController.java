package com.training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.ContactDAO;
import com.project.dao.ContactDeleteDAO;
import com.project.dao.ContactUpdateDAO;
import com.project.dao.impl.ContactDAOImpl;
import com.project.dao.impl.ContactDeleteDAOImpl;
import com.project.dao.impl.ContactUpdateDAOImpl;
import com.project.model.Contact;

@SuppressWarnings("serial")
@WebServlet("/contact1")
public class ContactController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		int id = Integer.parseInt(request.getParameter("usrid"));
		String name = request.getParameter("name");
		String email = request.getParameter("email1");
		String message = request.getParameter("message");
		long phone = Long.parseLong(request.getParameter("phone"));
		int contactid = Integer.parseInt(request.getParameter("contactid"));

		if (request.getParameter("deletecontact") != null) {
			Contact contact = new Contact(id);
			ContactDeleteDAO dao1 = new ContactDeleteDAOImpl();
			boolean status = dao1.deleteContact(contact);

			if (status)
				out.println("Contact Deleted Successfully");
			else
				out.println("Try Again");

		} else if (request.getParameter("contactupdate") != null) {
			Contact contact = new Contact(id, contactid, email, phone, message);
			ContactUpdateDAO dao3 = new ContactUpdateDAOImpl();
			boolean status = dao3.updateContact(contact);

			if (status)
				out.println("Contact Updated Successfully");
			else
				out.println("Try Again");

		} else {
			Contact contact = new Contact(id, name, email, phone, message);
			ContactDAO dao3 = new ContactDAOImpl();
			boolean status = dao3.saveContact(contact);

			if (status)
				out.println("Contact Saved Successfully");
			else
				out.println("Try Again");
		}

	}
}
