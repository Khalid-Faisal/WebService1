package com.training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.FeedbackDAO;
import com.project.dao.FeedbackDeleteDAO;
import com.project.dao.FeedbackUpdateDAO;
import com.project.dao.impl.FeedbackDAOImpl;
import com.project.dao.impl.FeedbackDeleteDAOImpl;
import com.project.dao.impl.FeedbackUpdateDAOImpl;
import com.project.model.Feedback;

@SuppressWarnings("serial")
@WebServlet("/feedback1")
public class FeedbackController extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String email = request.getParameter("email1");
		String mfeedback = request.getParameter("feedback");
		int fbid = Integer.parseInt(request.getParameter("feedbackid"));
		//out.print("\nName : "+name+"\n ID : "+id+"\n Feedback : "+mfeedback+"\nEmail : "+email);
		
		
		if (request.getParameter("deletefeedback") != null) {
			FeedbackDeleteDAO dao = new FeedbackDeleteDAOImpl();
			Feedback fb = new Feedback(fbid);
			
			boolean status = dao.deleteFeedback(fb);
			if(status)
				out.println("Feedback Deleted Successfully!!");
			else
				out.println("Try Again");

		} else if (request.getParameter("updatefeedback") != null) {
			FeedbackUpdateDAO dao2 = new FeedbackUpdateDAOImpl();
			Feedback fb2 = new Feedback(id, name, email, mfeedback);
			
			boolean status = dao2.updateFeedback(fb2);
			if(status)
				out.println("Feedback Updated Successfully!!");
			else
				out.println("Try Again");

		} else {
			FeedbackDAO dao1 = new FeedbackDAOImpl();
			Feedback fb1 = new Feedback(id, name, email, mfeedback);
			
			boolean status = dao1.saveFeedback(fb1);
			if(status)
				out.println("Feedback Submitted Successfully!!");
			else
				out.println("Try Again");
		}
	}
}
