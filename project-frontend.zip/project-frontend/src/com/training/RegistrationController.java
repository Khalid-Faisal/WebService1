package com.training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.UserDAO;
import com.project.dao.UserDeleteDAO;
import com.project.dao.UserUpdateDAO;
import com.project.dao.impl.UserDAOImpl;
import com.project.dao.impl.UserDeleteDAOImpl;
import com.project.dao.impl.UserUpdateDAOImpl;
import com.project.model.User;

@SuppressWarnings("serial")
@WebServlet("/register")
public class RegistrationController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		// out.print("Data (userid) : "+request.getParameter("usrid"));
		int userid = Integer.parseInt(request.getParameter("usrid"));
		String name = request.getParameter("name");
		String email = request.getParameter("email1");
		String password = request.getParameter("re_pass");
		String address = request.getParameter("address");
		String photo = request.getParameter("photo");
		long phone = Long.parseLong(request.getParameter("phone"));
		out.print("Name : "+name+"   ID : "+userid+"   Password : "+password+"  email : "+email+"  Phone : "+phone+"   Password : "+address+"    Photo : "+photo);
		User user = new User(userid, name, email, password, phone, address, photo);

		if (request.getParameter("deleteuser") != null) {
			User user1 = new User(userid);
			UserDeleteDAO dao2 = new UserDeleteDAOImpl();
			boolean status = dao2.deleteUser(user1);
			if (status)
				out.println("User Deleted Successfully");
			else
				out.println("Try Again");

		} else if (request.getParameter("userupdate") != null) {
			UserUpdateDAO dao1 = new UserUpdateDAOImpl();
			boolean status = dao1.updateUser(user);

			if (status)
				out.println("User Updated Successfully");
			else
				out.println("Try Again");

		} else {
			UserDAO dao = new UserDAOImpl();
			boolean status = dao.saveUser(user);

			if (status)
				out.println("User Saved Successfully");
			else
				out.println("Try Again");
		}
	}
}
