package com.training;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.CourseDAO;
import com.project.dao.CourseDeleteDAO;
import com.project.dao.CourseUpdateDAO;
import com.project.dao.impl.CourseDAOImpl;
import com.project.dao.impl.CourseDeleteDAOImpl;
import com.project.dao.impl.CourseUpdateDAOImpl;
import com.project.model.Course;

@SuppressWarnings("serial")
@WebServlet("/course1")
public class CourseController extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		int id = Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String description = request.getParameter("description");
		double fee = Double.parseDouble(request.getParameter("fee"));
		String ref = request.getParameter("refernces");
		//out.print("Name : "+name+"\t ID : "+id);
		
		Course course = new Course(id, name, description, fee, ref);
		if (request.getParameter("deletecourse") != null) {
			CourseDeleteDAO dao1 = new CourseDeleteDAOImpl();
			Course course1 = new Course(id);
			
			boolean status = dao1.deleteCourse(course1);
			
			if(status)
				out.println("Course Deleted Successfully");
			else
				out.println("Try Again");

		} else if (request.getParameter("updatecourse") != null) {
			CourseUpdateDAO dao2 = new CourseUpdateDAOImpl();
			
			boolean status = dao2.updateCourse(course);

			if (status)
				out.println("Course Updated Successfully");
			else
				out.println("Try Again");

		} else {
			CourseDAO dao = new CourseDAOImpl();
			boolean status = dao.saveCourse(course);
			
			if(status)
				out.println("Course Saved Successfully");
			else
				out.println("Try Again");
		}
	}
}
