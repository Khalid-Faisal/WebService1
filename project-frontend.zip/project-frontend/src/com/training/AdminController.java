package com.training;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.project.dao.AdminDAO;
import com.project.dao.impl.AdminDAOImpl;
import com.project.model.User;
import com.project.model.Admin;
import com.project.model.Contact;
import com.project.model.Course;
import com.project.model.Feedback;

@SuppressWarnings("serial")
@WebServlet("/login")
public class AdminController extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		PrintWriter out = response.getWriter();

		String email = request.getParameter("email1");
		String password = request.getParameter("password1");
		AdminDAO dao = new AdminDAOImpl();
		
		Admin admin = new Admin(email,password);
		Contact contact = new Contact();
		Course course = new Course();
		Feedback feedback = new Feedback();
		User user = new User();
		String resp = dao.validateAdmin(admin);
		ArrayList<String> resp1 = dao.getContacts(contact);
		ArrayList<String> resp2 = dao.getCourses(course);
		ArrayList<String> resp3 = dao.getFeedback(feedback);
		ArrayList<String> resp4 = dao.getUser(user);

		String[] cred = resp.split("-", 3);
		// out.println("\n\nChecking1 : "+cred[0]+"\nChecking2 : "+cred[1]);
		if (cred[1].equals(admin.getEmail()) && cred[2].equals(admin.getPassword())) {
			out.print("<html>");
			out.print("<head>");
			out.print("<title>Admin Page</title>");
			out.print("<head>");
			out.print("<body>");
			out.println("<h2 align='center'>Welcome "+cred[0]+"!!</h2><hr>");
			out.print("<br><h3 align=\"center\">Users</h3>");
			out.println("<table cellspacing='3' align=\"center\">");
			out.println("<tr align=\"center\"> <td><b>User Id</b></td><td><b>User Name</b></td><td><b>Email Id</b></td><td><b>Password</b></td><td><b>Address</b></td><td><b>Photo</b></td><td><b>Phone Number</b></td></tr>");
			for (int i = 0; i < resp4.size(); i++) {
				out.print("<tr align=\"center\">");
				for(int j=0;j< resp4.get(i).split(",").length;j++)
					out.println("<td align=\"center\">"+resp4.get(i).split(",")[j]+"</td>");
	            out.print("</tr>");
			}
			out.println("</table><br>");
			
			out.print("<br><hr><h3 align=\"center\">Courses</h3>");
			out.println("<table cellspacing=\"3\" align=\"center\">");
			out.println("<tr align=\"center\"> <td><b>Course Id</b></td><td><b>Course Name</b></td><td><b>Decription</b></td><td><b>Fees</b></td><td><b>Resources</b></td></tr>");
			for (int i = 0; i < resp2.size(); i++) {
				out.print("<tr align=\"center\">");
				for(int j=0;j< resp2.get(i).split(",").length;j++)
					out.println("<td align=\"center\">"+resp2.get(i).split(",")[j]+"</td>");
	            out.print("</tr>");
			}
			out.println("</table><br>");
			
			out.print("<br><hr><h3 align=\"center\">Contacts</h3>");
			out.println("<table cellspacing=\"3\" align=\"center\">");
			out.println("<tr align=\"center\"> <td><b>User Id</b></td><td><b>User Name</b></td><td><b>Email Id</b></td><td><b>Phone Number</b></td><td><b>Message</b></td><td><b>Contact Id</b></td></tr>");
			for (int i = 0; i < resp1.size(); i++) {
				out.print("<tr align=\"center\">");
				for(int j=0;j< resp1.get(i).split(",").length;j++)
					out.println("<td align=\"center\">"+resp1.get(i).split(",")[j]+"</td>");
	            out.print("</tr>");
			}
			out.println("</table><br>");

			out.print("<br><hr><h3 align=\"center\">Feedbacks</h3>");
			out.println("<table cellspacing=\"3\" align=\"center\">");
			out.println("<tr align=\"center\"> <td><b>User Id</b></td><td><b>User Name</b></td><td><b>Email Id</b></td><td><b>Feedback Message</b></td></tr>");
			for (int i = 0; i < resp3.size(); i++) {
			out.print("<tr align=\"center\">");
				for(int j=0;j< resp3.get(i).split(",").length;j++)
					out.println("<td align=\"center\">"+resp3.get(i).split(",")[j]+"</td>");
	            out.print("</tr>");
			}
			out.println("</table><br>");

			
			out.print("</body>");
			out.print("</html>");

			
			
		} else
			out.println("<h2 align=\"center\" color=\"red\">Login Failed!!!</h2>");
	}
}
