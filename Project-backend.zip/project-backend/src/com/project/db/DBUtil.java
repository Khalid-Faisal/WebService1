package com.project.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtil {
	static String url = "jdbc:oracle:thin:@localhost:1521:orcl";
	static String username = "elearning";
	static String password = "learning123";

	private static Connection conn = null;

	private DBUtil() {
	}

	public static Connection getConnection() {
		if (conn == null) {
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				conn = DriverManager.getConnection(url, username, password);
				return conn;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
}
