package com.project.dao;

import com.project.model.Contact;

public interface ContactDAO {
	boolean saveContact(Contact contact);
}
