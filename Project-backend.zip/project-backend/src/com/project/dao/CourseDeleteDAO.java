package com.project.dao;

import com.project.model.Course;

public interface CourseDeleteDAO {
	boolean deleteCourse(Course course);
}
