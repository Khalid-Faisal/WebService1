package com.project.dao;

import com.project.model.Feedback;

public interface FeedbackUpdateDAO {
	boolean updateFeedback(Feedback feedback);
}
