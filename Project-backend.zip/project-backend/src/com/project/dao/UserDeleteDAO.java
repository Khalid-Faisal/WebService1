package com.project.dao;

import com.project.model.User;

public interface UserDeleteDAO {
	boolean deleteUser(User user);
}
