package com.project.dao;

import com.project.model.Feedback;

public interface FeedbackDeleteDAO {
	boolean deleteFeedback(Feedback feedback);
}
