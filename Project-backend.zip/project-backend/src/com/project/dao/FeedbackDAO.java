package com.project.dao;

import com.project.model.Feedback;

public interface FeedbackDAO {
	boolean saveFeedback(Feedback feedback);
}
