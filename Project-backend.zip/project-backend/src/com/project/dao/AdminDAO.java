package com.project.dao;

import java.util.ArrayList;

import com.project.model.*;
public interface AdminDAO {
	String validateAdmin(Admin admin);
	ArrayList<String> getContacts(Contact contact);
	ArrayList<String> getUser(User user);
	ArrayList<String> getFeedback(Feedback feedback);
	ArrayList<String> getCourses(Course course);
}
