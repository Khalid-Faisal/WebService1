package com.project.dao;

import com.project.model.User;

public interface UserDAO {
	boolean saveUser(User user);
}
