package com.project.dao;

import com.project.model.Course;

public interface CourseDAO {
	boolean saveCourse(Course course);
}
