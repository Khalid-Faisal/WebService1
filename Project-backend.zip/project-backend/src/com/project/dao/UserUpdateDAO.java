package com.project.dao;

import com.project.model.User;

public interface UserUpdateDAO {
	boolean updateUser(User user);
}
