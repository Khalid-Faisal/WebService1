package com.project.dao;

import com.project.model.Course;

public interface CourseUpdateDAO {
	boolean updateCourse(Course course);
}
