package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.UserDeleteDAO;
import com.project.db.DBUtil;
import com.project.model.User;

public class UserDeleteDAOImpl implements UserDeleteDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean deleteUser(User user) {

		String query = "delete from contact where user_id = ?";
		String query1 = "delete from feedback where user_id = ?";
		String query2 = "delete from user1 where user_id = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, user.getId());
			ps.executeUpdate();
			
			PreparedStatement ps1 = conn.prepareStatement(query1);
			ps1.setInt(1, user.getId());
			ps1.executeUpdate();
			
			PreparedStatement ps2 = conn.prepareStatement(query2);
			ps2.setInt(1, user.getId());
			ps2.executeUpdate();
			
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
