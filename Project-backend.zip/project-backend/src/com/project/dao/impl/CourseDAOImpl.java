package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.CourseDAO;
import com.project.db.DBUtil;
import com.project.model.Course;

public class CourseDAOImpl implements CourseDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean saveCourse(Course course) {
		String query = "insert into course values(courseid.nextval,?,?,?,?)";

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			//ps.setInt(1, course.getCourseId());
			ps.setString(1, course.getCourseName());
			ps.setString(2, course.getDescription());
			ps.setDouble(3, course.getCourseFee());
			ps.setString(4, course.getResources());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
