package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.CourseUpdateDAO;
import com.project.db.DBUtil;
import com.project.model.Course;

public class CourseUpdateDAOImpl implements CourseUpdateDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean updateCourse(Course course) {
		String query = "update course set c_name=?,c_desp=?,c_fees=?,c_resource=? where course_id="+course.getCourseId();

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, course.getCourseName());
			ps.setString(2, course.getDescription());
			ps.setDouble(3, course.getCourseFee());
			ps.setString(4, course.getResources());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
