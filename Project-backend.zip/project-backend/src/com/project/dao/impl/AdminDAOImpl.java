package com.project.dao.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.project.dao.AdminDAO;
import com.project.db.DBUtil;
import com.project.model.Admin;
import com.project.model.Contact;
import com.project.model.Course;
import com.project.model.Feedback;
import com.project.model.User;

public class AdminDAOImpl implements AdminDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public String validateAdmin(Admin admin) {

		String query = "select name,email,password from admin";
		try {
			Statement st = conn.createStatement();
			boolean hasResult = st.execute(query);
		    if (hasResult) {
		     ResultSet rs = st.getResultSet();
		     while (rs.next()) {
		    	 String name =  rs.getString(1);
		    	 String email =  rs.getString(2);
		    	 String password =  rs.getString(3);
//		    	 String t = "";
//		    	 for(int i=0;i<password.length();i++)
//		    		 	t += "*";
//		    	 System.out.println("Email : "+email+"\nPassword "+t);
		    	 String resp=String.join("-",name,email,password);  
		    	 //System.out.println(resp);
		    	 return resp;
		     }
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return "Failed";
	}

	@Override
	public ArrayList<String> getContacts(Contact contact) {
		String query = "select * from contact";
		ArrayList<String> contacts = new ArrayList<String>();
		try {
			Statement st = conn.createStatement();
			boolean hasResult = st.execute(query);
		    if (hasResult) {
		     ResultSet rs = st.getResultSet();
		     while (rs.next()) {
		    	 String contactRow = contact.toString(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getLong(4), rs.getString(5), rs.getInt(6));
		    	 contacts.add(contactRow);
		    	 //System.out.println("["+contactRow+"]");
		     }
	    	 return contacts;
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		contacts.clear();
		contacts.add("No Contacts Found!!");
		return contacts;
	}

	@Override
	public ArrayList<String> getUser(User user) {
		String query = "select * from user1";
		ArrayList<String> users = new ArrayList<String>();
		try {
			Statement st = conn.createStatement();
			boolean hasResult = st.execute(query);
		    if (hasResult) {
		     ResultSet rs = st.getResultSet();
		     while (rs.next()) {
		    	 String userRow = user.toString(rs.getInt(1), rs.getString(2), rs.getString(4), rs.getString(7), rs.getString(5), rs.getString(8), rs.getLong(3));
		    	 users.add(userRow);
		    	// System.out.println("["+userRow+"]");
		     }
	    	 return users;
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		users.clear();
		users.add("No User Record Found!!");
		return users;
	}

	@Override
	public ArrayList<String> getFeedback(Feedback feedback) {
		String query = "select * from feedback";
		ArrayList<String> feedbacks = new ArrayList<String>();
		try {
			Statement st = conn.createStatement();
			boolean hasResult = st.execute(query);
		    if (hasResult) {
		     ResultSet rs = st.getResultSet();
		     while (rs.next()) {
		    	 String feedbackRow = feedback.toString(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(5)); 
		    	 feedbacks.add(feedbackRow);
		    	 //System.out.println("["+feedbackRow+"]");
		     }
	    	 return feedbacks;
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		feedbacks.clear();
		feedbacks.add("No Feedback Record Found!!");
		return feedbacks;
	}

	@Override
	public ArrayList<String> getCourses(Course course) {
		String query = "select * from course";
		ArrayList<String> courses = new ArrayList<String>();
		try {
			Statement st = conn.createStatement();
			boolean hasResult = st.execute(query);
		    if (hasResult) {
		     ResultSet rs = st.getResultSet();
		     while (rs.next()) {
		    	 String courseRow = course.toString(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDouble(4), rs.getString(5));
		    	 courses.add(courseRow);
		    	 //System.out.println("["+courseRow+"]");
		     }
	    	 return courses;
		    }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		courses.clear();
		courses.add("No Feedback Record Found!!");
		return courses;
	}
}
