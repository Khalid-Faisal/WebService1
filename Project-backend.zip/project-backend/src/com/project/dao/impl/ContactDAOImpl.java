package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.ContactDAO;
import com.project.db.DBUtil;
import com.project.model.Contact;

public class ContactDAOImpl implements ContactDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean saveContact(Contact contact) {
		String query = "insert into contact values(?,?,?,?,?,contactid.nextval)";

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, contact.getUserId());
			ps.setString(2, contact.getName());
			ps.setString(3, contact.getEmail());
			ps.setLong(4, contact.getPhone());
			ps.setString(5, contact.getMessage());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
