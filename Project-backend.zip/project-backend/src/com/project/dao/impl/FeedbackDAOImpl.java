package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.FeedbackDAO;
import com.project.db.DBUtil;
import com.project.model.Feedback;

public class FeedbackDAOImpl implements FeedbackDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean saveFeedback(Feedback feedback) {

		String query = "insert into feedback values(?,?,?,fbid.nextval,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, feedback.getUserId());
			ps.setString(2, feedback.getName());
			ps.setString(3, feedback.getEmail());
			//ps.setInt(4, 3);
			ps.setString(4, feedback.getFeedback());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
