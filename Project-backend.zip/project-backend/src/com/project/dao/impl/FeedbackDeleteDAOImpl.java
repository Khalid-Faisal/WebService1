package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.FeedbackDeleteDAO;
import com.project.db.DBUtil;
import com.project.model.Feedback;

public class FeedbackDeleteDAOImpl implements FeedbackDeleteDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean deleteFeedback(Feedback feedback) {

		String query = "delete from feedback where f_id = ?";
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, feedback.getUserId());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
