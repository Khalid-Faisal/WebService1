package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.ContactUpdateDAO;
import com.project.db.DBUtil;
import com.project.model.Contact;

public class ContactUpdateDAOImpl implements ContactUpdateDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean updateContact(Contact contact) {
		String query = "update contact set email=?, phone_no=?, messege=? where user_id="+contact.getUserId()+" and contact_id="+contact.getContactId();

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, contact.getEmail());
			ps.setLong(2, contact.getPhone());
			ps.setString(3, contact.getMessage());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
