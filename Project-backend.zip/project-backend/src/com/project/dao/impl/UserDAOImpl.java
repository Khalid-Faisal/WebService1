package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.UserDAO;
import com.project.db.DBUtil;
import com.project.model.User;

public class UserDAOImpl implements UserDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean saveUser(User user) {

		String query = "insert into user1 values(userid.nextval,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(query);
			//ps.setInt(1, user.getId());
			ps.setString(1, user.getName());
			ps.setLong(2, user.getPhone());
			ps.setString(3, user.getEmail());
			ps.setString(4, user.getAddress());
			ps.setString(5, user.getDate());
			ps.setString(6, user.getPassword());
			ps.setString(7, user.getPhoto());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
}
