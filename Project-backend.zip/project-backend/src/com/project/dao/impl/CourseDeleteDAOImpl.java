package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.CourseDeleteDAO;
import com.project.db.DBUtil;
import com.project.model.Course;

public class CourseDeleteDAOImpl implements CourseDeleteDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean deleteCourse(Course course) {
		String query = "delete from course where course_id = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, course.getCourseId());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
