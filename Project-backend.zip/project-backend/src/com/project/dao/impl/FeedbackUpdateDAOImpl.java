package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.FeedbackUpdateDAO;
import com.project.db.DBUtil;
import com.project.model.Feedback;

public class FeedbackUpdateDAOImpl implements FeedbackUpdateDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean updateFeedback(Feedback feedback) {
		String query = "update feedback set feedback=? where user_id="+feedback.getUserId()+" and f_id="+feedback.getFbId();

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setString(1, feedback.getFeedback());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
