package com.project.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.project.dao.ContactDeleteDAO;
import com.project.db.DBUtil;
import com.project.model.Contact;

public class ContactDeleteDAOImpl implements ContactDeleteDAO {
	Connection conn = DBUtil.getConnection();

	@Override
	public boolean deleteContact(Contact contact) {
		String query = "delete from contact where contact_id = ?";

		try {
			PreparedStatement ps = conn.prepareStatement(query);
			ps.setInt(1, contact.getUserId());
			ps.executeUpdate();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return false;
	}
}
