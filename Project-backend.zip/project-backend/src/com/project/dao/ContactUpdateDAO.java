package com.project.dao;


import com.project.model.Contact;

public interface ContactUpdateDAO {
	boolean updateContact(Contact contact);
}
