package com.project.dao;

import com.project.model.Contact;

public interface ContactDeleteDAO {
	boolean deleteContact(Contact contact);
}
