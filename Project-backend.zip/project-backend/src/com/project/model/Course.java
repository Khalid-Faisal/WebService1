package com.project.model;

public class Course {
	private int courseId;
	private String courseName;
	private String description;
	private double courseFee;
	private String resources;
	
	public Course() {}
	public Course(int courseId) {
		super();
		this.courseId = courseId;
	}
	public Course(int courseId, String courseName, String description, double courseFee, String resources) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.description = description;
		this.courseFee = courseFee;
		this.resources = resources;
	}
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public double getCourseFee() {
		return courseFee;
	}
	public void setCourseFee(double courseFee) {
		this.courseFee = courseFee;
	}
	public String getResources() {
		return resources;
	}
	public void setResources(String resources) {
		this.resources = resources;
	}
	public String toString(int courseId, String courseName, String description, double courseFee, String resourses) {
		return String.valueOf(courseId)+","+courseName+","+description+","+String.valueOf(courseFee)+","+resourses;
	}
	
}
