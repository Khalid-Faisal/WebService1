package com.project.model;

import java.text.SimpleDateFormat;
import java.util.Date;

public class User {
	private int id;
	private String name;
	private String email;
	private String password;
	private String address;
	private String photo;
	private long phone;
	SimpleDateFormat ft = new SimpleDateFormat ("dd-MM-yy");
	Date date = new Date();
	public User() {}
	public User(int id) {
		super();
		this.id = id;
	}
	public User(int id, String name,String email, String password, long phone, String address, String photo) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.password = password;
		this.address = address;
		this.photo = photo;
		this.phone = phone;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getDate() {
		return ft.format(date);
	}
	public String toString(int userId, String name, String email, String password, String address, String photo, long phone) {
		return String.valueOf(userId)+","+name+","+email+","+password+","+address+","+photo+","+String.valueOf(phone);
	}
}
