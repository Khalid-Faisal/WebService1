package com.project.model;

public class Contact {
	private int userId;
	private String Name;
	private String email;
	private long phone;
	private String message;
	private int contactId;
	public Contact() {}
	public Contact(int userId) {
		super();
		this.userId = userId;
	}
	public Contact(int userId, int contactId, String email, long phone, String message) {
		super();
		this.userId = userId;
		this.contactId = contactId;
		this.email = email;
		this.phone = phone;
		this.message = message;
	}
	public Contact(int userId, String Name, String email, long phone, String message) {
		super();
		this.userId = userId;
		this.Name = Name;
		this.email = email;
		this.phone = phone;
		this.message = message;
	}
	public int getContactId() {
		return contactId;
	}
	public void setContactId(int contactId) {
		this.contactId = contactId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String toString(int userId, String name, String email, long phone, String message, int contactId) {
		return String.valueOf(userId)+","+name+","+email+","+String.valueOf(phone)+","+message+","+contactId;
	}
}
