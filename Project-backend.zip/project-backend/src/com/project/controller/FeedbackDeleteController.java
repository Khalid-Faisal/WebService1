package com.project.controller;

import com.project.dao.FeedbackDeleteDAO;
import com.project.dao.impl.FeedbackDeleteDAOImpl;
import com.project.model.Feedback;

public class FeedbackDeleteController {

	public static void main(String[] args) {
		FeedbackDeleteDAO dao = new FeedbackDeleteDAOImpl();
		//Insert f_id here.. For ease I get input in userid
		Feedback fb = new Feedback(21);
		
		dao.deleteFeedback(fb);
		System.out.println("Feedback Deleted Successfully");

	}

}
