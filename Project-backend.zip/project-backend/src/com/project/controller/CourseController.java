package com.project.controller;

import com.project.dao.CourseDAO;
import com.project.dao.impl.CourseDAOImpl;
import com.project.model.Course;

public class CourseController {

	public static void main(String[] args) {
		CourseDAO  dao = new CourseDAOImpl();
		
		Course course = new Course(1003, "Lisp", "Basics only", 1500, "lisp123.mkv");
		
		dao.saveCourse(course);
		
		System.out.println("course saved successfully");

	}

}
