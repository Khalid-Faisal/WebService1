package com.project.controller;

import com.project.dao.CourseUpdateDAO;
import com.project.dao.impl.CourseUpdateDAOImpl;
import com.project.model.Course;

public class CourseUpdateController {

	public static void main(String[] args) {
		CourseUpdateDAO dao = new CourseUpdateDAOImpl();
		
		Course course = new Course(112, "Java Programming", "Web services", 999, "jsp_tutorial.mkv,java_basics.mp4");
		dao.updateCourse(course);
		System.out.println("course updated successfully");
	}

}
