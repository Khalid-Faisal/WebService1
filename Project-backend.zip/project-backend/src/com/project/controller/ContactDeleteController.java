package com.project.controller;

import com.project.dao.ContactDeleteDAO;
import com.project.dao.impl.ContactDeleteDAOImpl;
import com.project.model.Contact;

public class ContactDeleteController {

	public static void main(String[] args) {
		ContactDeleteDAO  dao = new ContactDeleteDAOImpl();
		
		Contact contact = new Contact(21);
		
		dao.deleteContact(contact);
		
		System.out.println("contact deleted successfully");

	}

}
