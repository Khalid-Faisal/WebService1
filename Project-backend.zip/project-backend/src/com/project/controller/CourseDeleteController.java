package com.project.controller;

import com.project.dao.CourseDeleteDAO;
import com.project.dao.impl.CourseDeleteDAOImpl;
import com.project.model.Course;

public class CourseDeleteController {

	public static void main(String[] args) {
		CourseDeleteDAO  dao = new CourseDeleteDAOImpl();
		
		Course course = new Course(130);
		
		dao.deleteCourse(course);
		
		System.out.println("course deleted successfully");

	}

}
