package com.project.controller;

import java.util.ArrayList;

import com.project.dao.AdminDAO;
import com.project.dao.impl.AdminDAOImpl;
import com.project.model.*;

public class AdminController {

	public static void main(String[] args) {
		AdminDAO dao = new AdminDAOImpl();

		Admin admin = new Admin("ankit@gmail.com", "pass");
		Contact contact = new Contact();
		Course course = new Course();
		Feedback feedback = new Feedback();
		User user = new User();
		String resp = dao.validateAdmin(admin);
		ArrayList<String> resp1 = dao.getContacts(contact);
		ArrayList<String> resp2 = dao.getCourses(course);
		ArrayList<String> resp3 = dao.getFeedback(feedback);
		ArrayList<String> resp4 = dao.getUser(user);

		String[] cred = resp.split("-", 3);
		 System.out.println("\n\nChecking1 : "+cred[0]+"\nChecking2 : "+cred[1]);
		if (cred[1].equals(admin.getEmail()) && cred[2].equals(admin.getPassword())) {
			System.out.println("Welcome "+cred[0]);
			
			System.out.println("\n--- Users --- ");
			for (int i = 0; i < resp4.size(); i++)
	            System.out.println(resp4.get(i));
			
			System.out.println("\n--- Courses --- ");
			for (int i = 0; i < resp2.size(); i++)
	            System.out.println(resp2.get(i));
			
			System.out.println("\n--- Contacts --- ");
			for (int i = 0; i < resp1.size(); i++)
	            System.out.println(resp1.get(i));
			
			System.out.println("\n--- Feedbacks --- ");
			for (int i = 0; i < resp3.size(); i++)
	            System.out.println(resp3.get(i));
		} else
			System.out.println("Login Failed!!!");
	}

}
