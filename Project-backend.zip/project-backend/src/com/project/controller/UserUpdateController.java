package com.project.controller;


import com.project.dao.UserUpdateDAO;
import com.project.dao.impl.UserUpdateDAOImpl;
import com.project.model.User;

public class UserUpdateController {

	public static void main(String[] args) {
		UserUpdateDAO dao = new UserUpdateDAOImpl();
		
		User user = new User(140, "Khalid","khalid.datamax@gmail.com","Khalid1234", 8983746099L, "Jalgaon", "image123.jpg");
		dao.updateUser(user);
		System.out.println("User Updated Successfully");
	}

}
