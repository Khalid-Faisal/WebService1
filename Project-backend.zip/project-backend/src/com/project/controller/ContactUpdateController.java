package com.project.controller;

import com.project.dao.ContactUpdateDAO;
import com.project.dao.impl.ContactUpdateDAOImpl;
import com.project.model.Contact;

public class ContactUpdateController {

	public static void main(String[] args) {
		ContactUpdateDAO dao = new ContactUpdateDAOImpl();
		
		Contact contact = new Contact(140, 5, "khalid.datamax@gmail.com", 8983746099L, "AD_CPD");
		dao.updateContact(contact);
		System.out.println("User Updated Successfully");
	}

}
