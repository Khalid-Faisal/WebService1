package com.project.controller;

import com.project.dao.UserDeleteDAO;
import com.project.dao.impl.UserDeleteDAOImpl;
import com.project.model.User;

public class UserDeleteController {

	public static void main(String[] args) {
		UserDeleteDAO dao = new UserDeleteDAOImpl();
		
		User user = new User(160);
		
		dao.deleteUser(user);
		System.out.println("User Deleted Successfully");

	}

}
