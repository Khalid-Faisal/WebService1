package com.project.controller;

import com.project.dao.FeedbackDAO;
import com.project.dao.impl.FeedbackDAOImpl;
import com.project.model.Feedback;

public class FeedbackController {

	public static void main(String[] args) {
		FeedbackDAO dao = new FeedbackDAOImpl();
		
		Feedback fb = new Feedback(160, "dummy","dummy@gmail.com","dummy books..");
		
		dao.saveFeedback(fb);
		System.out.println("Feedback Saved Successfully");

	}

}
