package com.project.controller;

import com.project.dao.FeedbackUpdateDAO;
import com.project.dao.impl.FeedbackUpdateDAOImpl;
import com.project.model.Feedback;

public class FeedbackUpdateController {

	public static void main(String[] args) {
		FeedbackUpdateDAO dao = new FeedbackUpdateDAOImpl();
		
		Feedback feedback = new Feedback(140,3,"Updated Feedback");
		dao.updateFeedback(feedback);
		System.out.println("Feedback Updated Successfully");
	}

}
