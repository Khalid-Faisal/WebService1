package com.project.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import com.project.dao.UserDAO;
import com.project.dao.impl.UserDAOImpl;
import com.project.model.User;

//@TestMethodOrder(OrderAnnotation.class)
class UserDAOJUnitTest {
	static User user = null; 
	static UserDAO userdao = null;
	
	@BeforeAll
	public static void init() {
		user = new User();
		userdao = new UserDAOImpl();
	}
	
	@Test
	//@Order(1)
	public void a_test_add_user_success() {
		user = new User(101, "dummy","dummy@dummy.com","dummy", 1234567890L, "dummy", "dummy.png");
		assertEquals(true, userdao.saveUser(user));
	}
	
	@AfterAll
	public static void destroy() {
		user = null;
		userdao = null;
	}
}
